require(['../common/common'],function(c){
    require(['jquery','template','md5','global','slider','base'],function($,template,md5,api){
        //用户信息页面
        function userInfo(data,api,success) {
            $.ajax({
                type:"get",
                async:true,
                traditional :true,
                data: data,
                dataType: "json",
                url:api+'/api/user_info',
                contentType: "application/json; charset=utf-8",
                success : function(msg){
                    console.log(msg)
                    //var User_data = {
                    //    user_name :"user_name",
                   //     user_type:"user_type",
                    //    phone_no:"phone_no"
                    //};
                    var User_data = msg;
                    var html = template("seller-content-uinfo",User_data);
                    document.getElementById('seller-content-userinfo').innerHTML = html;
                },
                error:function(){
                    alert('发生错误，请求数据失败！');
                },
            });
        }
        var user_id = 1000000003,
            access_token = "da2c29b1-0db9-434d-860d-93834ca0f576";


        var userData =  {
            "user_id":user_id,
            "access_token":access_token
        };
        userInfo(userData,"http://192.168.100.90/api");
    });
});