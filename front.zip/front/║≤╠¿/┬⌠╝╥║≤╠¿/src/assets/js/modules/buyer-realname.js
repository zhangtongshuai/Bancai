require(['../common/common'],function(c){
    require(['jquery','template','md5','global','slider','base'],function($,template,md5,api){
        
    	/**
    	 * 数据渲染
    	 */
		$.get('include/realnamecon.html', function(realdata) {
			/*optional stuff to do after success */
			var render = template.compile(realdata);
			//
			var user_id = 1000000006,
				access_token = "056f4368-690a-4820-a3ef-b6238f62d713",
				ent_name = "青岛九九网络科技有限公司";
			//
			//查看企业认证信息
			$.ajax({
				type: 'get',
				url: api + "/api/Cert_Ent",
				data: {
					"user_id": user_id,
					"access_token": access_token,
					"ent_name": ent_name
				},
				dataType: "json"
			}).then(function(realData){
				//console.log(realData);
				if (realData.err_code == 0) {
					if (realData.data == null) {
						$(".buyer-right-bottom").css({"display": "none"});
						$(".buyer-data-null").css({"display": "block"});
					}else{
						var html = render(realData);
						$("#realnamecon").html(html);

						$(".buyer-right-bottom div").eq(11).find("span").eq(1).on("click", function(){
							window.open("http:" + realData.data.cert_img);
						});
					}
				}else{
					$(".buyer-right-bottom").css({"display": "none"});
					$(".buyer-data-null").html("系统出现异常").css({"display": "block"});
				}
			});
		});

		$.get("include/realnameper.html", function(realperdata){
			var render = template.compile(realperdata);

			var user_id = 1000000003,
				access_token = "da2c29b1-0db9-434d-860d-93834ca0f576";
			
			//查看个人认证信息
			$.ajax({
				type: "get",
				url: api + "/api/Cert_User",
				data: {
					"user_id": user_id,
					"access_token": access_token
				},
				dataType: "json"
			}).then(function(personData){
				//console.log(personData);
				if (personData.err_code == 0) {
					if (personData.data == null) {
						$(".buyer-right-bottom-p").css({"display": "none"});
						$(".buyer-data-null-person").css({"display": "block"});
					}else{

						var html = render(personData);
						$("#realnameper").html(html);

						$(".buyer-right-bottom-p div").eq(2).find("span").eq(1).on("click", function(){
							window.open("http:" + personData.data.id_card_img);
						});
					}
				}else{
					$(".buyer-right-bottom-p").css({"display": "none"});
					$(".buyer-data-null-person").html("系统出现异常").css({"display": "block"});
				}
			});
		});


    	/**
    	 * 交互效果
    	 */
        var hSpan = $(".header-top-box h2").eq(1).find("span").text(),//消息气泡
			mcartNum = $(".header-top-box .m-cart span").text();//购物车气泡;
    	
        // 二维码显示隐藏
        $(".buyer-header .user-info li").eq(3).mouseenter(function(){
        	$(this).find("img").removeClass("hideen");
        }).mouseleave(function(){
        	$(this).find("img").addClass("hideen");
        });
        //消息和购物车右上角气泡显示隐藏
		if (parseInt(hSpan) != 0) {
			$(".header-top-box h2").eq(1).find("span").css({"visibility": 'visible'});
		}
		if (parseInt(mcartNum) != 0) {
			$(".header-top-box .m-cart span").css({"display": 'inline-block'});
		}
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(5)").find("a").css({"color": "#ff3c00"});
    });
});