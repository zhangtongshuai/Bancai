require(['../common/common'],function(c){
    require(['jquery','template','md5','global','slider','base'],function($,template,md5,api){
        //积分级别页面
        function integra(data,api,success) {
            $.ajax({
                type:"get",
                async:true,
                traditional :true,
                data: data,
                dataType: "json",
                url:api+'/api/integral',
                contentType: "application/json; charset=utf-8",
                success : function(msg){
                    console.log(msg)
                    // var integral_data = {
                    //    level:'level',
                    //    integral:'integral'
                    // };
                    var integral_data = msg;
                    var html = template("seller-content-uinte",integral_data);
                    document.getElementById('seller-content-integral').innerHTML = html;
                },
                error:function(){
                    alert('发生错误，请求数据失败！');
                }
            });
        }
        var user_id = 1000000003,
            access_token = "da2c29b1-0db9-434d-860d-93834ca0f576";
        var integraldata =  {
            "user_id":user_id,
            "access_token":access_token
        };
        integra(integraldata,"http://192.168.100.90/api");
    });
});