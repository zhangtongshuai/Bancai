require(['../common/common'],function(c){
    require(['jquery','template'],function($,template){
    /**
     * 数据渲染
     */
    orderRender()
    function orderRender(){
        function GetQueryString(name){
             var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
             var r = window.location.search.substr(1).match(reg);
             if(r!=null)return  unescape(r[2]); return null;
        }
        var url="https://cnodejs.org/api/v1/topic/"+ GetQueryString("id");
            $.ajax({
                url:url,
                type:'get',
                dataType:'json',
                success:function(r){
                   var html=template('tpl-articlelist',r.data);
                    document.getElementById('articlelist').innerHTML = html;
                }
            })
        }
        /**
         * 交互效果
         */
		

    });
});