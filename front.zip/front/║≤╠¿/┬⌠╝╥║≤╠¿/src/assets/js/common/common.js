requirejs.config({
    paths:{
        'template':'../lib/template',
        'jquery':'../lib/jquery.min',
        'base':'../modules/base',
        'jquery.lazyload':'../lib/jquery.lazyload.min',
        'slider':'../lib/slider',
        'jquery.validate':'../lib/jquery.validate.min',
        'md5':'../lib/md5.min',
        'global':'../modules/global'
    },
    shim: {
        "slider": {
            deps: ['jquery']
        }
    }
});