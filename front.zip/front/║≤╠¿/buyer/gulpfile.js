var gulp = require('gulp');
var fileinclude  = require('gulp-file-include');

gulp.task('fileinclude', function() {
    gulp.src('src/**.html')
        .pipe(fileinclude({
          prefix: '@@',
          basepath: '@file'
        }))
    .pipe(gulp.dest('dist'));
});

gulp.task("default", function(){
	gulp.src("./src/assets/css/*.css")
		.pipe(gulp.dest("dist/assets/css"));
		
	gulp.src("./src/assets/js/common/*.js")
		.pipe(gulp.dest("dist/assets/js/common"));
		
	gulp.src("./src/assets/js/lib/*.js")
		.pipe(gulp.dest("dist/assets/js/lib"));
		
	gulp.src("./src/assets/js/modules/*.js")
		.pipe(gulp.dest("dist/assets/js/modules"));
		
	gulp.src("./src/assets/images/*")
		.pipe(gulp.dest("dist/assets/images"));
		
	gulp.src("./src/include/*.html")
		.pipe(gulp.dest("dist/include"));
	
});
