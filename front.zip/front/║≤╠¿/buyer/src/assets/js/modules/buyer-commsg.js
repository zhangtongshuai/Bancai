require(['../common/common'],function(c){
    require(['jquery','template','md5','global','jquery.cookie','slider','base'],function($,template,md5,api){
        
    	/**
    	 * 数据渲染
    	 */
        
    	 $.get("include/company.html", function(companymsgData){
    	 	var render = template.compile(companymsgData);
    	 	//
			var user_id = 1000000003,
				access_token = "da2c29b1-0db9-434d-860d-93834ca0f576",
				ent_name = "青岛九九网络科技有限公司";
			//
			//获取公司信息
			$.ajax({
				type: 'get',
				url: api + '/api/Ent_Info',
				data: {
					"user_id": user_id,
					"access_token": access_token,
					"ent_name": ent_name
				},
				dataType: 'json'
			}).then(function(companyData){
				//console.log(companyData);
				if (companyData.err_code == 0) {
					if (companyData.data != null) {
						var html = render(companyData);
						$("#companymsg").html(html);
					}
				}
			});
    	 });

    	/**
    	 * 交互效果
    	 */
    	var hSpan = $(".header-top-box h2").eq(1).find("span").text(),//消息气泡
			mcartNum = $(".header-top-box .m-cart span").text();//购物车气泡;
			
        // 二维码显示隐藏
        $(".buyer-header .user-info li").eq(3).mouseenter(function(){
        	$(this).find("img").removeClass("hideen");
        }).mouseleave(function(){
        	$(this).find("img").addClass("hideen");
        });
        //消息和购物车右上角气泡显示隐藏
		if (parseInt(hSpan) != 0) {
			$(".header-top-box h2").eq(1).find("span").css({"visibility": 'visible'});
		}
		if (parseInt(mcartNum) != 0) {
			$(".header-top-box .m-cart span").css({"display": 'inline-block'});
		}
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(4)").find("a").css({"color": "#ff3c00"});
    });
});