require(['../common/common'],function(c){
    require(['jquery','template','md5','global','jquery.cookie','slider','base'],function($,template,md5,api){
        
    	/**
    	 * 数据渲染
    	 */
	 	//
		var user_id = 1000000003,
			access_token = "da2c29b1-0db9-434d-860d-93834ca0f576";
		//
		
		//获取公司信息
		$.ajax({
			type: 'get',
			url: api + '/api/Contacts',
			data: {
				"user_id": user_id,
				"access_token": access_token
			},
			dataType: 'json'
		}).then(function(certData){
			console.log(certData);
			if (certData.err_code == 0) {
				if (certData.data != null) {
					$("#contains-btn").val(certData.data.contacts);
					$("#phone-btn").val(certData.data.phone_no);
					$("#email-btn").val(certData.data.email);
				}else{
					
				}
			}
		});
		
		$(".buyer-right-bottom button").on("click", function(){
			changeContains();
		});
		
		
		function changeContains(){
			var containsObj = {
				user_id: user_id,
				access_token: access_token,
				contacts: $("#contains-btn").val(),
				phone_no: $("#phone-btn").val(),
				email: $("#email-btn").val()
			};
			console.log(containsObj);
			if (containsObj.contacts == "") {
				$(".buyer-right-bottom > span").html("联系人信息不能为空");
				$("#contains-btn").focus();
				return false;
			}else if (containsObj.phone_no == "" || !/^[0-9]+$/.test(containsObj.phone_no)) {
				$(".buyer-right-bottom > span").html("电话信息不正确");
				$("#phone-btn").focus();
				return false;
			}else if (containsObj.email == "" || !/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/.test(containsObj.email)) {
				$(".buyer-right-bottom > span").html("邮箱信息不正确");
				$("#email-btn").focus();
				return false;
			}else{
				$.ajax({
					type: "post",
					url: api + "/api/Contacts",
					async:true,
					data: JSON.stringify(containsObj),
					dataType: "json"
				}).then(function(changmsg){
					window.location.reload();
				});
			}
		}
		
    	/**
    	 * 交互效果
    	 */
    	var hSpan = $(".header-top-box h2").eq(1).find("span").text(),//消息气泡
			mcartNum = $(".header-top-box .m-cart span").text();//购物车气泡;
			
        // 二维码显示隐藏
        $(".buyer-header .user-info li").eq(3).mouseenter(function(){
        	$(this).find("img").removeClass("hideen");
        }).mouseleave(function(){
        	$(this).find("img").addClass("hideen");
        });
        //消息和购物车右上角气泡显示隐藏
		if (parseInt(hSpan) != 0) {
			$(".header-top-box h2").eq(1).find("span").css({"visibility": 'visible'});
		}
		if (parseInt(mcartNum) != 0) {
			$(".header-top-box .m-cart span").css({"display": 'inline-block'});
		}
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(0).find("dd:nth-of-type(3)").find("a").css({"color": "#ff3c00"});
    });
});