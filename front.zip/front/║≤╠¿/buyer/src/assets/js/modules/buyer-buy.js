require(['../common/common'],function(c){
    require(['jquery','template','md5','global','jquery.cookie','slider','base'],function($,template,md5,api){
        
    	/**
    	 * 数据渲染
    	 */
        var aa = $.cookie('access_token'),
			bb = $.cookie('user_id'),
			cc = $.cookie('err_code'),
			dd = $.cookie('msg');
        console.log(aa,bb,cc,dd);
        
        
    	 //点击发布按钮
		$("#change-psw-submit").on("click", function(){
			var cateVal = $(".cate").html(),
				cateMingVal = $(".cate-ming").html(),
				cateModelVal = $(".cate-model").html(),
				danWeiVal = $("#dan").val(),
				priceVal = $("#price").val(),
				payAddress = $("#pay-address").val(),
				payContains = $("#pay-contains").val(),
				payUsername = $("#pay-username").val(),
				textareaVal = $("textarea").val();

			//
			var user_id = 1000000003,
				access_token = "da2c29b1-0db9-434d-860d-93834ca0f576";
			//

			if ("" == cateVal) {
				$(".error-msg").html("品类没有选择");
			}else if ("" == cateMingVal) {
				$(".error-msg").html("品名没有选择");
			}else if ("" == cateModelVal) {
				$(".error-msg").html("规格没有选择");
			}else if ("" == danWeiVal) {
				$(".error-msg").html("采购数量没有填入");
			}else if ("" == priceVal) {
				$(".error-msg").html("预期价格没有填入");
			}else if ("" == payAddress) {
				$(".error-msg").html("交货地点没有填入");
			}else if ("" == payContains) {
				$(".error-msg").html("联系方式没有填入");
			}else if ("" == payUsername) {
				$(".error-msg").html("您的称呼没有填入");
			}else{
				$(".error-msg").html("");
				//发布请求
				
				
			}
		});

    	/**
    	 * 交互效果
    	 */
    	//所有的全局变量
        var hSpan = $(".header-top-box h2").eq(1).find("span").text(),//获取消息右上角元素内容
			mcartNum = $(".header-top-box .m-cart span").text();//获得购物车右上角元素内容
        //消息和购物车右上角的数量显示隐藏
		if (parseInt(hSpan) != 0) {
			$(".header-top-box h2").eq(1).find("span").css({"visibility": 'visible'});
		}
		if (parseInt(mcartNum) != 0) {
			$(".header-top-box .m-cart span").css({"display": 'inline-block'});
		}
        // 二维码显示隐藏
        $(".buyer-header .user-info li").eq(3).mouseenter(function(){
        	$(this).find("img").removeClass("hideen");
        }).mouseleave(function(){
        	$(this).find("img").addClass("hideen");
        });
		
		//下拉框
		$(".cate").on("click", function(){
			$(".cate-down").toggle();
		});
		$(".cate-ming").on("click", function(){
			$(".cate-ming-down").toggle();
		});
		$(".cate-model").on("click", function(){
			$(".cate-model-down").toggle();
		});
		$(".dan-wei").on("click", function(){
			$(".dan-wei-down").toggle();
		});
		$(".dan-wei-one").on("click", function(){
			$(".dan-wei-one-down").toggle();
		});
		
		//输入框获得焦点后
		$("#dan").on("focus", function(){
			$(".dan-wei-down").hide();
		});
		$("#price").on("focus", function(){
			$(".dan-wei-one-down").hide();
		});
		
		//点击后显示
		$(".cate-down span").on("click", function(){
			$(".cate").html($(this).html());
			$(".cate-down").hide();
		});
		$(".cate-ming-down span").on("click", function(){
			$(".cate-ming").html($(this).html());
			$(".cate-ming-down").hide();
		});
		$(".cate-model-down span").on("click", function(){
			$(".cate-model").html($(this).html());
			$(".cate-model-down").hide();
		});
		$(".dan-wei-down span").on("click", function(){
			$(".dan-wei").html("&nbsp;&nbsp;&nbsp;" + $(this).html());
			$(".dan-wei-down").hide();
		});
		$(".dan-wei-one-down span").on("click", function(){
			$(".dan-wei-one").html("&nbsp;" + $(this).html());
			$(".dan-wei-one-down").hide();
		});
		
		//左侧栏颜色改变
		$(".buyer-content .buyer-slider dl").eq(1).find("dd:nth-of-type(1)").find("a").css({"color": "#ff3c00"});
    });
});