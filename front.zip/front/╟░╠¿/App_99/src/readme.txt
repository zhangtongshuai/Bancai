﻿/**
@SUN 2017.11.24
 ## 项目目录结构
 */
├──assets     静态资源
│ ├─css       
│ │ ├─base.css基础样式表（重置 公用类  字体库  基础ui  公共部分等）
│ │
│ ├─font      图标字体库
│ ├─images    图片库
│ ├─js
│    ├─common 公共基础配置文件
│    │ ├common.js      
│    │
│    ├─lib    
│    │ ├require.js    模块管理库
│    │ ├templage.js   前端模板引擎 
│    │ ├jquery.js     基础库
│    │ ├···        其他依赖
│    │
│    ├─modules        模块依赖
│    │ ├base.js       公共js
│    │ ├index.js      首页模块
│    │ ├···        其他模块
│       
├──include     公用文件（复用组件-->打包）
│ ├─header.html头部  
│ ├─footer.html底部   
│ ├─sider.html 侧边 
│  
├──index  首页
│   ···  其它页面 
├──404    404页面

