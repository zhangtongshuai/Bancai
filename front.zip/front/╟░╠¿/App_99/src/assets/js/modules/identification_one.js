require(['../common/common'],function(c){
    require(['jquery','template'],function($,template){
    /**
     * 数据渲染
     */
	    $(".toEnterprise").click(function toEnterprise(){
	        window.location.href = "identification_four.html";
	    })
	    $(".toPersonal").click(function toPersonal(){
	        window.location.href = "identification_two.html";
	    })
        /**
         * 交互效果
         */



    });
});