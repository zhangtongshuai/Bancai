/**
 * 网站公用js
 */
require(['../common/common'],function(c){
    require(['jquery'],function($){
       
    	/**
    	 * 公用效果
    	 */
        //顶部下拉菜单
        $('.user-top ul li').hover(function(){
            $(this).find('.top-subnav').show().parent().addClass('active');
        },function(){
            $(this).removeClass('active').find('.top-subnav').hide();
        });
        // 头部地区根据ip获取
         $.getScript('http://int.dpool.sina.com.cn/iplookup/iplookup.php?format=js', function(_result) {
             if (remote_ip_info.ret == '1') {
                $('.top-position').find('span').text(remote_ip_info.city);
             } 
         });
        //导航
        $('.all-cate').hover(function(){
            $('.all-catelist').show();
        },function(){
            $('.all-catelist').hide();
            $('#index .all-catelist').show();
        });
        $('.all-catelist li').hover(function(){
            $(this).addClass('current');
        },function(){
            $(this).removeClass('current');
        });
    	//分类搜索模拟
       $(".select_box").click(function(event){   
            event.stopPropagation();
            $(this).find(".option").toggle();
            $(this).parent().siblings().find(".option").hide();
        });
        $(document).click(function(event){
            var eo=$(event.target);
            if($(".select_box").is(":visible") && eo.attr("class")!="option" && !eo.parent(".option").length);
            $('.option').hide();                                      
        });
        $(".option a").click(function(){
            var value=$(this).text();
            $(this).parent().siblings(".select_txt").text(value);
            $("#select_value").val(value)
         });



    });
});