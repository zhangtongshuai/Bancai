require(['../common/common'],function(c){
    require(['jquery','template','exif','jquery.cookie'],function($,template,Cookies){
	    /**
	     * 数据渲染
	     */
	    
	    // 定义变量
	    var relname;//用户真实姓名
	    var idcardno;//用户身份证号
	    var idcardimg;//用户照片
	    var access_token;
	    var user_id;
	    
		localStorage.setItem('id_card_img',"");

	    $(".continue").click(function(){
	    	$(".club").html("");
	    	var id_card_img = localStorage.getItem("id_card_img");
			relname = $(".relname").val();
			idcardno = $(".idcardno").val();
			idcardimg = id_card_img;
			if (relname.length != 0&&idcardno.length != 0&&idcardimg.length != 0) {
				toAjaxPersonally(idcardimg);
			}
			else{
				$(".club").html("用户信息填写不完整或已提交认证");
			}
	        // window.location.href = "identification_three.html";
	    })


		function toAjaxPersonally(picUrl){
		 	var user = {
				real_name:$(".relname").val(),
				id_card_no:$(".idcardno").val(),
				id_card_img:picUrl,
				access_token:$.cookie('access_token'),
				user_id:$.cookie('user_id')
				// access_token = $.cookie('access_token');
			    //  console.log(access_token);
			    //  user_id = $.cookie('user_id');
			    //  console.log(user_id);
			}
		 	var url="http://192.168.100.90/api/api/Cert_User";
            $.ajax({
                url:url,
                type:'post',
                contentType: "application/json; charset=utf-8", 
		        dataType:'json',
		        data:JSON.stringify(user),
                success:function(personData){
                	console.log(personData);
                	if (personData.err_code == 0) {
                		$(".club").html("提交成功");
		        		window.location.href = "identification_three.html";
		        	}
                   	else{
                   		$(".club").html("提交失败");
                   	}
                }
            })
		 }


		var pictureFile;//图片base64信息
		/* 2015-09-28 上传图片*/
		function convertImgToBase64(url, callback, outputFormat) {
			var canvas = document.createElement('CANVAS');
			var ctx = canvas.getContext('2d');
			var img = new Image;
			img.crossOrigin = 'Anonymous';
			img.onload = function() {
				var width = img.width;
				var height = img.height;
				// 按比例压缩4倍
				var rate = (width < height ? width / height : height / width) / 4;
				canvas.width = width * rate;
				canvas.height = height * rate;
				ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
				var dataURL = canvas.toDataURL(outputFormat || 'image/png');
				callback.call(this, dataURL);
				canvas = null;
			};
			img.src = url;
		}

		function getObjectURL(file) {
			var url = null;
			if(window.createObjectURL != undefined) { // basic
				url = window.createObjectURL(file);
			} else if(window.URL != undefined) { // mozilla(firefox)
				url = window.URL.createObjectURL(file);
			} else if(window.webkitURL != undefined) { // web_kit or chrome
				url = window.webkitURL.createObjectURL(file);
			}
			return url;
		} 
		// 前端只需要给input file绑定这个change事件即可（上面两个方法不用管）upload-file为input的id
		$('#imgInp').on('change', function(event) {
			// console.log(123465);
			//获取图片的大小
			var fileSize = this.files[0].size;
			$('.club').html("");
			//对于图片的大小进行比较
			if (fileSize > 1*1024*1024) {
				$('.club').html("上传图片大小不能超过1M");
			}
			else{
				var imageUrl = getObjectURL($(this)[0].files[0]);
				convertImgToBase64(imageUrl, function(base64Img) {
					// base64Img为转好的base64,放在img src直接前台展示(<img src="data:image/jpg;base64,/9j/4QMZRXh...." />)
					// console.log(base64Img);
					pictureFile = base64Img;
					localStorage.setItem('id_card_img',pictureFile);
					//上传成功
					$('.club').html("上传成功");
					// base64转图片不需要base64的前缀data:image/jpg;base64
					//console.log(base64Img.split(",")[1]);
				});
				event.preventDefault();
			}
		});






    });
});