require(['../common/common'],function(c){
    require(['jquery','template','exif','jquery.cookie'],function($,template,Cookies){
	    /**
	     * 数据渲染
	     */
	    
	    // 定义变量
	 //    var relname;//用户真实姓名
	 //    var idcardno;//用户身份证号
	 //    var idcardimg;//用户照片
	 //    var access_token;
	 //    var user_id;
	    
		// localStorage.setItem('id_card_img',"");
		//生成左侧列表
		var ent_data = [  
	        {"id":1,"ent_title":"企业名称"},  
	        {"id":2,"ent_title":"企业状态"},
	        {"id":3,"ent_title":"地址"},  
	        {"id":4,"ent_title":"法人"},  
	        {"id":5,"ent_title":"统一社会信用代码"},  
	        {"id":6,"ent_title":"机构代码"},  
	        {"id":7,"ent_title":"经营期限"},  
	        {"id":8,"ent_title":"注册区域"},  
	        {"id":9,"ent_title":"注册资金"},
	        {"id":10,"ent_title":"注册类型"},  
	        {"id":11,"ent_title":"邮箱"},  
	        {"id":12,"ent_title":"网址"},  
	        {"id":13,"ent_title":"注册时间"},  
	        {"id":14,"ent_title":"经营范围"}
		];
		$.each(ent_data, function(i, listObj) {
			$('.left_lists').append('<li class="'+listObj.id+'"><span>'+listObj.ent_title+'</span></li>');
		});
//	    $(".continue").click(function(){
	  //   	$(".club").html("");
	  //   	var id_card_img = localStorage.getItem("id_card_img");
			// relname = $(".relname").val();
			// idcardno = $(".idcardno").val();
			// idcardimg = id_card_img;
			// if (relname.length != 0&&idcardno.length != 0&&idcardimg.length != 0) {
				toAjaxEntinfo();
			// }
			// else{
			// 	$(".club").html("用户信息填写不完整或已提交认证");
			// }
	        // window.location.href = "identification_three.html";
//	    })


		function toAjaxEntinfo(){
			var token = $.cookie('access_token');
			var id = $.cookie('user_id');
			var name = $.cookie('ent_name');
		 	var url="http://192.168.100.90/api/api/Ent_info?access_token="+token+"&user_id="+id+"&ent_name=青岛九九网络科技有限公司";
            $.ajax({
                url:url,
                type:'get',
                // contentType: "application/json; charset=utf-8", 
		        dataType:'json',
		        // data:JSON.stringify(user),
                success:function(entData){
                	console.log(333);
                	console.log(entData);
					$('.companyName').html(entData.data.companyName);
					$('.businessStatus').html(entData.data.businessStatus);
					$('.address').html(entData.data.address);
					$('.faRen').html(entData.data.faRen);
					$('.creditCode').html(entData.data.creditCode);
					$('.companyCode').html(entData.data.companyCode);
					$('.bussiness').html(entData.data.bussiness);
					$('.areaName').html(entData.data.areaName);
					$('.regMoney').html(entData.data.regMoney);
					$('.regType').html(entData.data.regType);
					$('.email').html(entData.data.email);
					$('.website').html(entData.data.website);
					$('.issueTime').html(entData.data.issueTime);
					$('.bussinessDes').html(entData.data.bussinessDes);
           //      	if (personData.err_code == 0) {
           //      		$(".club").html("提交成功");
		        	// 	window.location.href = "identification_three.html";
		        	// }
           //         	else{
           //         		$(".club").html("提交失败");
           //         	}
                }
            })
		 }





    });
});