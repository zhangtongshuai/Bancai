require(['../common/common'], function(c) {
	require(['jquery', 'template', 'md5','basetool'], function($, template,basetool) {
		/**
		 * 接口api
		 */
		var api = 'http://192.168.100.90';
		function GetQueryString(name) {
			var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
			var r = window.location.search.substr(1).match(reg);
			if(r != null) return unescape(r[2]);
			return null;
		}
		/*
		 * 定义变量
		 */
		var password//密码
		var phone;//手机号
		var cpwd;//确认密码
		var code;//手机验证码
		var condition;//正则判断条件
		var url;//网络请求接口
		var usertype;// 买家登录 0 卖家登录 1
			usertype = GetQueryString('usertype');
		/*
		 * 获取验证码
		 */
		/* 定时器  */
		var InterValObj; //timer变量，控制时间
		var count = 180; //间隔函数，1秒执行
		var curCount; //当前剩余秒数
		function sendMessage() {
			curCount = count;
			var dealType; //验证方式
			//设置button效果，开始计时
			$(".c-center-last-r").attr("disabled", "disabled");
			$(".c-center-last-r").addClass("c-center-last-change");
			$(".c-center-last-r").html("重新发送（" + curCount + "s）");
			InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次
		}
		

		$('.register-right-right').click(function() {
			window.location.href = "login_buyer.html?usertype=0";
		});
		//timer处理函数
		function SetRemainTime() {
			if(curCount == 0) {
				window.clearInterval(InterValObj); //停止计时器
				$(".c-center-last-r").removeAttr("disabled"); //启用按钮
				$(".c-center-last-r").removeClass("c-center-last-change");
				$(".c-center-last-r").html("获取验证码");
			} else {
				curCount--;
				$(".c-center-last-r").attr("disabled", "disabled");
				$(".c-center-last-r").addClass("c-center-last-change");
				$(".c-center-last-r").html("重新发送（" + curCount + "s）");
			}
		}
		
		/*获取验证码点击事件*/
		$(".c-center-last-r").click(function() {
			//发送验证码网络请求
			toAjaxCode();
		})
		function toAjaxCode(){
			phone = $(".mobile").val();
			usertype = GetQueryString('usertype');
		    var mathRand=""; 
			for(var i=0;i<6;i++){ 
				mathRand+=Math.floor(Math.random()*10); 
			}
			console.log(mathRand);
			localStorage.setItem('mathRand',mathRand);
		    var url = "http://192.168.100.90/api/api/Sms_Code?phone_no=" + phone + "&ver_code=" + mathRand + "&type=0";
		    $.ajax({
		        url:url,
		        type:'get',
		    	dataType:'json',
	            success:function(verificationCode){
	            	console.log(verificationCode);
	            	// 未完成
	            	if (verificationCode.err_code == 0) {
	            		sendMessage();
						Success(".mobile", ".mobileHint");
	            	}
		        }
		    })
		}
		/*
		 * 忘记密码前台判断正则
		 */
		//密码1判断
		 $('.password').on('input propertychange', function() {
		 	password = $(this).val();
		 	cpwd = $('.confirm-pwd').val();
		 	
		 	 if (cpwd.length>=0 && cpwd.length<4){
	            if (password.length >= 4 && password.length <=25) {
	                if (/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(password)) {
	                	Success(".password", ".pwdHint");
	                } else {
	                	Error(".password", ".pwdHint","密码格式不正确，必须包含字母和数字。");
	                }
	            } else {
	            	Error(".password", ".pwdHint","用户密码要在4~25位之间。");
	            }
	        } else{
	            if (password.length >= 4 && password.length <=25) {
	                if (/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(password)) {
	                    if (password==cpwd){
	                    	Success(".password", ".pwdHint");
	                    	Success(".confirm-pwd", ".cpwdHint");
	                    }else {
	                    	Error(".password", ".pwdHint","两次输入的密码不一致。");
	                    }
	                } else {
	                	Error(".password", ".pwdHint","密码格式不正确，必须包含字母和数字。");
	                }
	            } else {
	            	Error(".password", ".pwdHint","用户密码要在4~25位之间。");
	            }
	        }
		 });
		 // 密码2判断
		 $('.confirm-pwd').on('input propertychange', function() {
		 	cpwd = $(this).val();
		 	password = $('.password').val();

			 if (password.length<4 && password.length>=0){
			            
	            if (cpwd.length>=4 && cpwd.length <=25){
	                if (/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(cpwd)){
	                	Success(".confirm-pwd", ".cpwdHint");
	                }else {
	                	Error(".confirm-pwd", ".cpwdHint","密码格式不正确，必须包含字母和数字。");
	                }
	            }else {
	                Error(".confirm-pwd", ".cpwdHint","用户密码要在4~25位之间。");
	            }
	            
	        }else {
	            if (cpwd.length>=4 && cpwd.length <=25){
	                if (/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(cpwd)){
	                    if (password==cpwd){
	                    	Success(".password", ".pwdHint");
	                    	Success(".confirm-pwd", ".cpwdHint");
	                    }else {
	                	Error(".confirm-pwd", ".cpwdHint","两次输入的密码不一致。");
	                    }
	                }else {
	                	Error(".confirm-pwd", ".cpwdHint","密码格式不正确，必须包含字母和数字。");
	                }
	            }else {
	                Error(".confirm-pwd", ".cpwdHint","用户密码要在4~25位之间。");
	            }
	        }
		 });
		 //手机号判断
		$('.mobile').on('input propertychange', function() {
			phone = $(this).val();
			// condition = !(/^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(17([0,6-8]))|(18[0-9]))\d{8}$/.test(phone));
			condition = phoneCheck(phone);
			checkAll("number", phone, condition, Success, Error, ".mobile", ".mobileHint");
		});
		
		/*
		 * 当满足所有判断条件则确定按钮可以点击并修改
		 */
		$('input').bind('input propertychange', function() { 
			password = $(".password").val();
			phone = $(".mobile").val();
			cpwd = $(".confirm-pwd").val();
			code = $(".verificationCode").val();
			if(password.length >= 4&&cpwd == password&&phone.length == 11&&code.length == 6){
				$(".register-btn").removeAttr("disabled");
				$(".register-btn").removeClass("btndisabled");
			}
			else{
				$(".register-btn").attr("disabled","disabled");
				$(".register-btn").addClass("btndisabled");
			}
		});
		/*点击确认按钮进行修改请求*/
		$(".register-btn").click(function(){
			// 注册网络请求
			var mathRand = localStorage.getItem("mathRand");
			var ver_code = $('.verificationCode').val();
			if (ver_code == mathRand) {
				toAjaxRegister();
			}
			else{
				$(".clue").html("");
				$(".clue").html("输入的验证码不正确");
			}
		})
		function toAjaxRegister(){
			var user = {
				phone_no:$(".mobile").val(),
				pwd_new:md5($(".password").val()),
				type:'0'
			}
			url = "http://192.168.100.90/api/api/chg_pwd";
			$.ajax({
			    type:'post',
			    url:url,
			    contentType: "application/json; charset=utf-8", 
		        dataType:'json',
		        data:JSON.stringify(user),
		        success:function(registerData){
		        	console.log(registerData);
		        	if (registerData.err_code == 0) {
		        		console.log(usertype);
		        		window.location.href = "changepwdskip.html";
		        	}
		        	else{
		        		$(".clue").html("修改密码失败");
		        	}
				}
			})
		}
	})
});