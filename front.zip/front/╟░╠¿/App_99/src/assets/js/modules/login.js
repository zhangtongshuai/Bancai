require(['../common/common'],function(c){
    require(['jquery','template' ,'md5' ,'jquery.cookie','ipaddress'],function($,template,md5,Cookies,ipaddress){
		/**
		 * 接口api
		 */
		var api = 'http://192.168.100.90/api/';

		function GetQueryString(name) {
			var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
			var r = window.location.search.substr(1).match(reg);
			if(r != null) return unescape(r[2]);
			return null;
		}
		// 获取本地ip地址
		// console.log(returnCitySN["cip"],returnCitySN["cname"]);
		/*
		 * 定义变量
		 */
		var username;//用户名
		var password;//密码
		var usertype;// 买家登录 0 卖家登录 1
			usertype = GetQueryString('usertype');
		if(usertype == 0){
			$(".toseller").click(function(){
				window.location.href = "login_seller.html?usertype=1";
			})
			$(".sellerpwd").click(function() {
				window.location.href = "change_password.html?usertype=1";
			});
		}
		if(usertype == 1){
			$(".tobuyer").click(function(){
				window.location.href = "login_buyer.html?usertype=0";
			})
			$(".buyerpwd").click(function() {
				window.location.href = "change_password.html?usertype=0";
			});
		}

		/*
		 * 删除输入框中输入的内容
		 */
		$('input').bind('input propertychange', function() {
			username = $(".u-name").val();
			password = $(".u-pass").val();
			if(username.length != 0) {
				$(".x-name").addClass("show");
			}
			if(username.length == 0){
				$(".x-name").removeClass("show");
			}
			if(password.length != 0) {
				$(".x-pass").addClass("show");
			}
			if(password.length == 0){
				$(".x-pass").removeClass("show");
			}
			/*
			 * 判断是否可以点击登录
			 */
			if(username.length >= 2&&username.length <= 20&&password.length >= 4){
				$(".c-right ul li button").removeAttr("disabled");
				$(".c-right ul li button").removeClass("btndisabled");
			}else{
				$(".container .c-right ul li button").attr("disabled","disabled");
				$(".container .c-right ul li button").addClass("btndisabled");
			}
		});
		// 点击删除输入框内容
		$(".x-name").click(function(){
			$(".u-name").val("");
			$(".x-name").removeClass("show");
		});
		$(".x-pass").click(function(){
			$(".u-pass").val("");
			$(".x-pass").removeClass("show");
		});
		/*
		 * 登录网络请求
		 */
		 $(".loginbtn").click(function() {
			toAjaxLogin();
		 });
		 function toAjaxLogin(){
		 	var user = {
				user_name:$(".u-name").val(),
				password:md5($(".u-pass").val()),
				user_type:GetQueryString('usertype'),
				ip_address:returnCitySN["cip"]
			}
			usertype = GetQueryString('usertype');
		 	var url="http://192.168.100.90/api/api/User_Login";
		 	$(".club").html("");
            $.ajax({
                url:url,
                type:'post',
                contentType: "application/json; charset=utf-8", 
		        dataType:'json',
		        data:JSON.stringify(user),
                success:function(userloginData){
                	/*
                	 * 未完成 判断买家登录跳转买家中心，卖家登录跳转卖家登录，及判断用户名或密码错误。
                	 */
                	if (userloginData.err_code == 0) {
		        		if (usertype == 0) {
							$.cookie('access_token',userloginData.data.access_token);
							$.cookie('user_id',userloginData.data.user_id);
							$.cookie('err_code',userloginData.err_code);
							$.cookie('msg',userloginData.msg);
	                   		$(".club").html("买家登录成功");
			            }
				        if (usertype == 1) {
				        	$.cookie('access_token',userloginData.data.access_token);
							$.cookie('user_id',userloginData.data.user_id);
							$.cookie('err_code',userloginData.err_code);
							$.cookie('msg',userloginData.msg);
	                   		console.log(userloginData);
	                   		$(".club").html("卖家登录成功");
			            }
		        	}
	            	else{
	            		$(".club").html("用户名密码不正确");
	            	}
                   	
                }
            })
		 }
    });
});
