require(['../common/common'],function(c){
    require(['jquery','template'],function($,template){
    /**
     * 数据渲染
     */
	    $(".toBackBuyer").click(function toBackBuyer(){
	        window.location.href = "identification_one.html";
	    })


    });
});