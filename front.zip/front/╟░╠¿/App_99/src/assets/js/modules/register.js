require(['../common/common'], function(c) {
	require(['jquery', 'template', 'md5','basetool'], function($, template,basetool) {
		/**
		 * 接口api
		 */
		var api = 'http://192.168.100.90';
		/*
		 * 定义变量
		 */
		var username;//用户名
		var password//密码
		var phone;//手机号
		var cpwd;//确认密码
		var code;//手机验证码
		var spanWid;//选中协议框宽度
		var condition;//正则判断条件
		var usertype;//判断是买家还是卖家 0为买家 1为卖家
		var url;//网络请求接口
		var agechoose;//判断是否选中用户协议 1为选中 0为未选中
		/*
		 * 获取验证码
		 */
		/* 定时器  */
		var InterValObj; //timer变量，控制时间
		var count = 180; //间隔函数，1秒执行
		var curCount; //当前剩余秒数
		function sendMessage() {
			curCount = count;
			var dealType; //验证方式
			//设置button效果，开始计时
			$(".c-center-last-r").attr("disabled", "disabled");
			$(".c-center-last-r").addClass("c-center-last-change");
			$(".c-center-last-r").html("重新发送（" + curCount + "s）");
			InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次
		}
		

		$('.register-right-right').click(function() {
			window.location.href = "login_buyer.html?usertype=0";
		});
		//timer处理函数
		function SetRemainTime() {
			if(curCount == 0) {
				window.clearInterval(InterValObj); //停止计时器
				$(".c-center-last-r").removeAttr("disabled"); //启用按钮
				$(".c-center-last-r").removeClass("c-center-last-change");
				$(".c-center-last-r").html("获取验证码");
			} else {
				curCount--;
				$(".c-center-last-r").attr("disabled", "disabled");
				$(".c-center-last-r").addClass("c-center-last-change");
				$(".c-center-last-r").html("重新发送（" + curCount + "s）");
			}
		}
		
		/*获取验证码点击事件*/
		$(".c-center-last-r").click(function() {
			phone = $(".mobile").val();
			username = $(".userName").val();
			password = $(".password").val();
			cpwd = $(".confirm-pwd").val();
			if(!(/[\u4e00-\u9fa5_a-zA-Z0-9]+$/.test(username))||username.length < 2||username.length > 20) {
				Error(".mobile", ".nameHint");
			}
			else{
				if(password.length < 4||password.length > 25||(!(/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(password)))) {
					Error(".password", ".pwdHint");
				}
				else{
					Success(".password", ".pwdHint");
					if ((cpwd.length < 4)||(cpwd.length > 25)||(!(/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(cpwd)))) {
						Error(".confirm-pwd", ".cpwdHint","请输入4~25位密码，必须包含数字和字母。");
					}
					else{
						Success(".confirm-pwd", ".cpwdHint");
						if(cpwd != password) {
							Error(".confirm-pwd", ".cpwdHint","两次输入的密码不一致。");
						}
						else{
							if(!(/^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(17([0,6-8]))|(18[0-9]))\d{8}$/.test(phone))){
								Error(".mobile", ".mobileHint");
							}else{
								Success(".mobile", ".mobileHint");
								//发送验证码网络请求
								toAjaxCode();
							}
						}
					}
				}
			}
		})
		function toAjaxCode(){
			phone = $(".mobile").val();
		    var mathRand=""; 
			for(var i=0;i<6;i++){ 
				mathRand+=Math.floor(Math.random()*10); 
			}
			console.log(mathRand);
			localStorage.setItem('mathRand',mathRand);
		    var url = "/api/Sms_code?phone_no=" + phone + "&ver_code=" + mathRand;
		    $.ajax({
		        url:url,
		        type:'get',
		    	dataType:'json',
	            success:function(verificationCode){
	            	console.log(verificationCode);
	            	// 未完成
	            	if (verificationCode.err_code == 0) {
	            		sendMessage();
						Success(".mobile", ".nameHint");
						Success(".mobile", ".mobileHint");
	            	}
	            	if (verificationCode.err_code == 2001) {
	            		Error(".mobile", ".mobileHint","手机号已被注册，请直接登陆");
	            	}
		        }
		    })
		}
		/*
		 * 选择买家或卖家注册
		 */
		/*选择买家注册点击事件*/
		$(".choose-buyer,.choose-buyer-w").click(function() {
			$(".choose-buyer-w").addClass("cr");
			$(".choose-buyer").addClass("bc");
			$(".choose-seller").removeClass("bc");
			$(".choose-seller-w").removeClass("cr");
			$('.choose').attr("user_type",0);
		})
		/*选择卖家注册点击事件*/
		$(".choose-seller,.choose-seller-w").click(function() {
			$(".choose-seller-w").addClass("cr");
			$(".choose-seller").addClass("bc");
			$(".choose-buyer").removeClass("bc");
			$(".choose-buyer-w").removeClass("cr");
			$('.choose').attr("user_type",1);
		})
		/*
		 * 关于用户协议
		 * /
		/*选中板材网协议*/
		$(".agreement-s").click(function() {
			spanWid = $(this).css("width");
			if(spanWid == "10px") {
				Selected();
			}
			if(spanWid == "12px") {
				NoSelected();
			}
		})
		//选中时协议框样式回调
		function Selected() {
			$(".agreement-s").addClass("change");
			$(".agreement-s").attr("choose","1");
		};
		//未选中时协议框样式回调
		function NoSelected() {
			$(".agreement-s").removeClass("change");
			$(".agreement-s").attr("choose","0");
		};
		/*
		 * 注册前台判断正则
		 */
	 	//用户名判断
	 	$('.userName').on('input propertychange', function() {
			username = $(this).val();
			condition = !(/[\u4e00-\u9fa5_a-zA-Z0-9]+$/.test(username))||username.length < 2||username.length > 20;
			checkAll("text", username, condition, Success, Error, ".userName", ".nameHint");
		});
		//密码1判断
		 $('.password').on('input propertychange', function() {
		 	password = $(this).val();
		 	cpwd = $('.confirm-pwd').val();
		 	
		 	 if (cpwd.length>=0 && cpwd.length<4){
	            if (password.length >= 4 && password.length <=25) {
	                if (/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(password)) {
	                	Success(".password", ".pwdHint");
	                    // console.log("密码对了");
	                } else {
	                	Error(".password", ".pwdHint","密码格式不正确，必须包含字母和数字。");
	                    // console.log("密码格式不对");
	                }
	            } else {
	            	Error(".password", ".pwdHint","用户密码要在4~25位之间。");
	                // console.log("用户密码要在4~25位之间。");
	            }
	        } else{
	            if (password.length >= 4 && password.length <=25) {
	                if (/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(password)) {
	                    if (password==cpwd){
	                    	Success(".password", ".pwdHint");
	                    	Success(".confirm-pwd", ".cpwdHint");
	                        // console.log("密码是对的");
	                    }else {
	                    	Error(".password", ".pwdHint","两次输入的密码不一致。");
	                        // console.log("密码不一致");
	                    }
	                } else {
	                	Error(".password", ".pwdHint","密码格式不正确，必须包含字母和数字。");
	                    // console.log("密码格式不对");
	                }
	            } else {
	            	Error(".password", ".pwdHint","用户密码要在4~25位之间。");
	                // console.log("用户密码要大于四位");
	            }
	        }
		 });
		 // 密码2判断
		 $('.confirm-pwd').on('input propertychange', function() {
		 	cpwd = $(this).val();
		 	password = $('.password').val();

			 if (password.length<4 && password.length>=0){
			            
	            if (cpwd.length>=4 && cpwd.length <=25){
	                if (/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(cpwd)){
	                	Success(".confirm-pwd", ".cpwdHint");
	                    // console.log("密码对了");
	                }else {
	                	Error(".confirm-pwd", ".cpwdHint","密码格式不正确，必须包含字母和数字。");
	                    // console.log("密码格式不对");
	                }
	            }else {
	                Error(".confirm-pwd", ".cpwdHint","用户密码要在4~25位之间。");
	                // console.log("密码长度要大于四位");
	            }
	            
	        }else {
	            if (cpwd.length>=4 && cpwd.length <=25){
	                if (/^(?!^[0-9]*$)(?!^[a-zA-Z]*$)(?!^[^a-zA-Z0-9]*$)\S{4,25}/.test(cpwd)){
	                    if (password==cpwd){
	                    	Success(".password", ".pwdHint");
	                    	Success(".confirm-pwd", ".cpwdHint");
	                        // console.log("密码对了");
	                    }else {
	                	Error(".confirm-pwd", ".cpwdHint","两次输入的密码不一致。");
	                        // console.log("密码1与密码2不相等");
	                    }
	                }else {
	                	Error(".confirm-pwd", ".cpwdHint","密码格式不正确，必须包含字母和数字。");
	                    // console.log("密码2的格式不对");
	                }
	            }else {
	                Error(".confirm-pwd", ".cpwdHint","用户密码要在4~25位之间。");
	                // console.log("密码长度要大于四位");
	            }
	        }
		 });
		 //手机号判断
		$('.mobile').on('input propertychange', function() {
			phone = $(this).val();
			// condition = !(/^((13[0-9])|(14[5|7])|(15([0-3]|[5-9]))|(17([0,6-8]))|(18[0-9]))\d{8}$/.test(phone));
			condition = phoneCheck(phone);
			checkAll("number", phone, condition, Success, Error, ".mobile", ".mobileHint");
		});
		
		/*
		 * 当满足所有判断条件则注册按钮可以点击并注册
		 */
		$('input').bind('input propertychange', function() { 
			username = $(".userName").val();
			password = $(".password").val();
			phone = $(".mobile").val();
			cpwd = $(".confirm-pwd").val();
			code = $(".verificationCode").val();
			if((/[\u4e00-\u9fa5_a-zA-Z0-9]+$/.test(username))&&username.length >= 2&&username.length <= 20&&password.length >= 4&&cpwd == password&&phone.length == 11&&code.length == 6){
				$(".register-btn").removeAttr("disabled");
				$(".register-btn").removeClass("btndisabled");
			}
			else{
				$(".register-btn").attr("disabled","disabled");
				$(".register-btn").addClass("btndisabled");
			}
		});
		/*点击注册按钮进行注册请求*/
		$(".register-btn").click(function(){
			usertype = $(".choose").attr("user_type");
			agechoose = $(".agreement-s").attr("choose");
			if (agechoose != 1){
				$(".clue").html("");
				$(".clue").html("同意网站服务条款才可以进行注册");
			}
			if(usertype != 0&&usertype != 1) {
				$(".clue").html("");
				$(".clue").html("请选择是买家注册还是卖家注册");
			}
			if((agechoose == 1)&&(usertype == 0||usertype == 1)){
				$(".clue").html("");
				// window.location.href = "registerskip.html?usertype=" + usertype;
				// 注册网络请求
				var mathRand = localStorage.getItem("mathRand");
				var ver_code = $('.verificationCode').val();
				if (ver_code == mathRand) {
					toAjaxRegister();
				}
				else{
					$(".clue").html("");
					$(".clue").html("输入的验证码不正确");
				}
			}
		})
		function toAjaxRegister(){
			usertype = $(".choose").attr("user_type");
			var user = {
				user_name:$(".userName").val(),
				password:md5($(".password").val()),
				phone_no:$(".mobile").val(),
				user_type:$(".choose").attr("user_type")
			}
			url = "http://192.168.100.90/api/api/User_Register";
			$.ajax({
			    type:'post',
			    url:url,
			    contentType: "application/json; charset=utf-8", 
		        dataType:'json',
		        data:JSON.stringify(user),
		        success:function(registerData){
		        	console.log(registerData);
		        	if (registerData.err_code == 0) {
		        		console.log(usertype);
		        		window.location.href = "registerskip.html?usertype=" + usertype;
		        	}
	            	if (registerData.err_code == 2002) {
	            		Error(".mobile", ".nameHint","用户名已被占用");
	            	}
		        	if (registerData.err_code == 2001) {
	            		Error(".mobile", ".mobileHint","手机号已被注册，请直接登陆");
	            	}
				}
			})
		}
	})
});