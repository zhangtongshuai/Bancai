require(['../common/common'],function(c){
    require(['jquery','template'],function($,template){
    /**
     * 数据渲染
     */
        function GetQueryString(name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
            var r = window.location.search.substr(1).match(reg);
            if(r != null) return unescape(r[2]);
            return null;
        }
        
        var usertype = GetQueryString('usertype');
	    $(".toLogin").click(function toLogin(){
            if (usertype == 0) {
                window.location.href = "login_buyer.html?usertype=0";
            }
	        if (usertype == 1) {
                window.location.href = "login_seller.html?usertype=1";
            }
	    })
        /**
         * 交互效果
         */



    });
});