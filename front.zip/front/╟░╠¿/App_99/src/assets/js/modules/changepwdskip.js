require(['../common/common'],function(c){
    require(['jquery','template'],function($,template){
    /**
     * 数据渲染
     */
	    $(".toIndex").click(function toIndex(){
            window.location.href = "index.html?";
	    })

    });
});