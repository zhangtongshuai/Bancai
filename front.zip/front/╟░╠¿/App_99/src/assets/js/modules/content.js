require(['../common/common'],function(c){
    require(['jquery','template'],function($,template){
    /**
     * 数据渲染
     */
    /**
     * 交互效果
     */



    });
});