require(['../common/common'],function(c){
    require(['jquery','template','jquery.cookie','area'],function($,template,Cookies,area){
	    /**
	     * 数据渲染
	     */

 		// 定义变量
	    var ent_type;//企业所属行业
	    var ent_name;//企业名称
	    var ent_code;//统一社会信用代码
	    var start_years;//营业年限
	    var ent_plos;//员工人数
	    var country;//国家
	    var province;//省份
	    var city;//城市
	    var district;//区/县
	    var address;//详细地址
	    var phone;//固定电话
	    var fax;//传真
	    var cert_img;//营业执照

		//生成左侧列表
		var ent_data = [  
	        {"id":1,"required":"*","ent_title":"企业所属行业:"},  
	        {"id":2,"required":"*","ent_title":"企业名称:"},
	        {"id":3,"required":"*","ent_title":"统一社会信用代码:"},  
	        {"id":4,"required":"*","ent_title":"营业年限:"},  
	        {"id":5,"required":"*","ent_title":"员工人数:"},  
	        {"id":6,"required":"*","ent_title":"国家:"},  
	        {"id":7,"required":"*","ent_title":"省份:"},  
	        {"id":8,"required":"*","ent_title":"城市:"},  
	        {"id":9,"required":"*","ent_title":"区/县:"},
	        {"id":10,"required":"","ent_title":"详细地址:"},  
	        {"id":11,"required":"","ent_title":"固定电话:"},  
	        {"id":12,"required":"","ent_title":"传真:"},  
	        {"id":13,"required":"*","ent_title":"营业执照:"}
		];
		$.each(ent_data, function(i, listObj) {
			$('.left_lists').append('<li class="'+listObj.id+'"><i>' + listObj.required + '</i><span>'+listObj.ent_title+'</span></li>');
		});

		localStorage.setItem('cert_img',"");
		/*
		 * 点击继续按钮进行操作
		 */
	    $(".continue").click(function(){
	    	$(".club").html("");
//	    	ent_type;//企业所属行业
//	    	ent_name;//企业名称
//	    	ent_code;//统一社会信用代码
//	    	start_years;//营业年限
//	    	ent_plos;//员工人数
//	    	country;//国家
//	    	province;//省份
//	    	city;//城市
//	    	district;//区/县
//	    	address;//详细地址
//	    	phone;//固定电话
//	    	fax;//传真
//	    	cert_img;//营业执照
	    	certimg = localStorage.getItem("cert_img");
//			if (relname.length != 0&&idcardno.length != 0&&idcardimg.length != 0) {
				toAjaxEnterprise(certimg);
//			}
//			else{
//				$(".club").html("用户信息填写不完整");
//			}
	        // window.location.href = "identification_five.html";
	    })

	  	// 企业认证网络请求
		function toAjaxEnterprise(picUrl){
		 	var user = {
		 		ent_type:$(".ent_type").text(),
		    	ent_name:$(".ent_name").val(),
		    	ent_code:$(".ent_code").val(),
		    	start_years:$(".start_years").text(),
		    	ent_plos:$(".ent_plos").text(),
		    	country:$(".country").text(),
		    	province:$("#province option:selected").text(),
		    	city:$("#city option:selected").text(),
		    	district:$("#town option:selected").text(),
		    	address:$(".address").val(),
		    	phone:$(".phone").val(),
		    	fax:$(".fax").val(),
				cert_img:picUrl,
				access_token:$.cookie('access_token'),
				user_id:$.cookie('user_id')
			}
		 	var url="http://192.168.100.90/api/api/Cert_Ent";
            $.ajax({
                url:url,
                type:'post',
                contentType: "application/json; charset=utf-8", 
		        dataType:'json',
		        data:JSON.stringify(user),
                success:function(entData){
                	console.log(entData);
                	if (entData.err_code == 0) {
                		$.cookie('ent_name',$(".ent_name").val());
                		$(".club").html("提交成功");
//		        		window.location.href = "identification_five.html";
		        	}
                   	else{
                   		$(".club").html("提交失败");
                   	}
                }
            })
		 }


		var pictureFile;//图片base64信息
		/* 2015-09-28 上传图片*/
		function convertImgToBase64(url, callback, outputFormat) {
			var canvas = document.createElement('CANVAS');
			var ctx = canvas.getContext('2d');
			var img = new Image;
			img.crossOrigin = 'Anonymous';
			img.onload = function() {
				var width = img.width;
				var height = img.height;
				// 按比例压缩4倍
				var rate = (width < height ? width / height : height / width) / 4;
				canvas.width = width * rate;
				canvas.height = height * rate;
				ctx.drawImage(img, 0, 0, width, height, 0, 0, width * rate, height * rate);
				var dataURL = canvas.toDataURL(outputFormat || 'image/png');
				callback.call(this, dataURL);
				canvas = null;
			};
			img.src = url;
		}

		function getObjectURL(file) {
			var url = null;
			if(window.createObjectURL != undefined) { // basic
				url = window.createObjectURL(file);
			} else if(window.URL != undefined) { // mozilla(firefox)
				url = window.URL.createObjectURL(file);
			} else if(window.webkitURL != undefined) { // web_kit or chrome
				url = window.webkitURL.createObjectURL(file);
			}
			return url;
		} 
		// 前端只需要给input file绑定这个change事件即可（上面两个方法不用管）upload-file为input的id
		$('#imgInp').on('change', function(event) {
			// console.log(123465);
			//获取图片的大小
			var fileSize = this.files[0].size;
			$('.club').html("");
			//对于图片的大小进行比较
			if (fileSize > 1*1024*1024) {
				$('.club').html("上传图片大小不能超过1M");
			}
			else{
				var imageUrl = getObjectURL($(this)[0].files[0]);
				convertImgToBase64(imageUrl, function(base64Img) {
					// base64Img为转好的base64,放在img src直接前台展示(<img src="data:image/jpg;base64,/9j/4QMZRXh...." />)
					// console.log(base64Img);
					pictureFile = base64Img;
					localStorage.setItem('cert_img',pictureFile);
					//上传成功
					$('.club').html("上传成功");
					// base64转图片不需要base64的前缀data:image/jpg;base64
					//console.log(base64Img.split(",")[1]);
				});
				event.preventDefault();
			}
		});


		
		//子导航展开收缩
		$(".sewvtop").click(function(){
			$(this).next(".sewvbm").toggle().parents(".sewv").siblings().find(".sewvbm").hide();
		});
		/*鼠标离开下拉框关闭*/
		// $(".sewv").mouseleave(function(){
		// 	$(".sewvbm").hide();
		// });
		//赋值
		$(".sewvbm>li").click(function(){
			var selva=$(this).text();
			$(this).parents(".sewvbm").siblings(".sewvtop").find("span").text(selva);
			$(this).parent("ul").hide();
		});
		
		//省市区三级联动	
		var province=$("#province"),city=$("#city"),town=$("#town");
		for(var i=0;i<provinceList.length;i++){
		    addEle(province,provinceList[i].name);
		}
		function addEle(ele,value){
		    var optionStr="";
		    optionStr="<option value="+value+">"+value+"</option>";
		    ele.append(optionStr);
		}
		function removeEle(ele){
		    ele.find("option").remove();
		    var optionStar="<option value="+"请选择"+">"+"请选择"+"</option>";
		    ele.append(optionStar);
		}
		var provinceText,cityText,cityItem;
		province.on("change",function(){
		    provinceText=$(this).val();
		    $("#province").attr("val",provinceText);
		    $.each(provinceList,function(i,item){
		        if(provinceText == item.name){
		            cityItem=i;
		            return cityItem
		        }
		    });
		    removeEle(city);
		    removeEle(town);
		    $.each(provinceList[cityItem].cityList,function(i,item){
		        addEle(city,item.name)
		    })
		});
		city.on("change",function(){
		    cityText=$(this).val();
		    $("#city").attr("val",cityText);
		    removeEle(town);
		    $.each(provinceList,function(i,item){
		        if(provinceText == item.name){
		            cityItem=i;
		            return cityItem
		        }
		    });
		    $.each(provinceList[cityItem].cityList,function(i,item){
		        if(cityText == item.name){
		            for(var n=0;n<item.areaList.length;n++){
		                addEle(town,item.areaList[n])
		            }
		        }
		    });
		});



    });
});