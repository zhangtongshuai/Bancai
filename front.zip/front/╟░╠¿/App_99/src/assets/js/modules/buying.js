/**
 * 网站公用js
 */
require(['../common/common'],function(c){
    require(['jquery','base','marquee'],function($){
       
		$(".ortable-bd").myScroll({
			speed:40, //数值越大，速度越慢
			rowHeight:68 //li的高度
		});

    });
});