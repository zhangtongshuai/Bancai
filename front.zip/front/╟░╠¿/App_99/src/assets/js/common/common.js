requirejs.config({
    paths:{
    	'template':'../lib/template',
        'jquery':'../lib/jquery.min',
        'base':'../modules/base',
        'slider':'../lib/slider',
        'validator': '../lib/zh-CN',
        'marquee':'../lib/marquee',
        'md5':'../lib/md5.min',
        'exif':'../lib/exif',
        'jquery.cookie':'../lib/jquery.cookie',
        'area':'../lib/area',
        'basetool':'../lib/basetool',
        'ipaddress':'http://pv.sohu.com/cityjson?ie=utf-8'

    },
    shim: {
        slider: ['jquery'],
        marquee: ['jquery'],
        validator:['../lib/jquery.validator']
    }
});